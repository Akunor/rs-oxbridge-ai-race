import type { Metadata } from "next";
import Link from "next/link";
import { Nav } from "@/components/Nav";
import { modules } from "@/lib/modules";
import "./globals.css";

// Fonts load in the browser from Google Fonts, so building needs no network. Archivo's width
// axis (62–125) gives the wide headings. Swap the link and the --sans/--mono tokens in globals.css to restyle.
const FONTS =
  "https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,400..800&family=Martian+Mono:wght@400;500;600&display=swap";

export const metadata: Metadata = {
  title: "PayeeGuard · Confirmation of Payee for AI agents",
  description: "PayeeGuard checks who an AI agent is paying before money moves: address poisoning, payee swaps and prompt-injected payment requests.",
};

// PayeeGuard pages first, then every page from the starter's modules.
const links = [
  { href: "/", label: "How it works" },
  { href: "/shop", label: "Demo shop" },
  { href: "/merchant/verify", label: "Verify a wallet" },
  { href: "/developers", label: "For agents" },
  { href: "/receipts", label: "Receipts" },
  { href: "/setup", label: "Setup" },
  ...modules.filter((m) => m.href).map((m) => ({ href: m.href!, label: m.name })),
];
const usesPayments = modules.some((m) => m.id === "payments");

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href={FONTS} />
      </head>
      <body>
        <header className="header">
          <div className="header-inner">
            <Link href="/" className="wordmark">
              <b>🛡 PAYEEGUARD</b>
              <span>made with Agent Studio</span>
            </Link>
            <Nav links={links} />
          </div>
        </header>
        <main className="page">{children}</main>
        <footer className="footer">
          <div className="footer-inner">
            <span>{usesPayments ? "SOLANA DEVNET · TEST MONEY ONLY" : "STARTER PROJECT"}</span>
            <span>
              PAYEEGUARD · CONFIRMATION OF PAYEE FOR AI AGENTS
            </span>
          </div>
        </footer>
      </body>
    </html>
  );
}
